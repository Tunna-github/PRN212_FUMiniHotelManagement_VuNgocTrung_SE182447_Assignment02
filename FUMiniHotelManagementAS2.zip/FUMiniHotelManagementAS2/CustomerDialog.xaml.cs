﻿using BusinessObjects.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FUMiniHotelManagementAS2
{
    /// <summary>
    /// Interaction logic for CustomerDialog.xaml
    /// </summary>
    public partial class CustomerDialog : Window
    {
        public Customer Customer { get; private set; }

        public CustomerDialog(Customer customer)
        {
            InitializeComponent();
            Customer = customer ?? new Customer(); 

            FullNameTextBox.Text = Customer.CustomerFullName;
            EmailTextBox.Text = Customer.EmailAddress;
            TelephoneTextBox.Text = Customer.Telephone;
            BirthdayPicker.SelectedDate = Customer.CustomerBirthday.ToDateTime(new TimeOnly());
            PasswordBox.Password = Customer.Password; 
            StatusComboBox.SelectedItem = Customer.CustomerStatus == 1 ? StatusComboBox.Items[0] : StatusComboBox.Items[1];
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(FullNameTextBox.Text) || string.IsNullOrWhiteSpace(EmailTextBox.Text) || string.IsNullOrEmpty(PasswordBox.Password))
            {
                MessageBox.Show("Full Name and Email and Password are required.");
                return;
            }

            Customer.CustomerFullName = FullNameTextBox.Text;
            Customer.EmailAddress = EmailTextBox.Text;
            Customer.Telephone = TelephoneTextBox.Text;
            Customer.CustomerBirthday = BirthdayPicker.SelectedDate.HasValue ? DateOnly.FromDateTime(BirthdayPicker.SelectedDate.Value) : DateOnly.MinValue;
            Customer.Password = PasswordBox.Password; 
            Customer.CustomerStatus = (StatusComboBox.SelectedItem as ComboBoxItem).Content.ToString().StartsWith("1") ? 1 : 2; ;

            DialogResult = true; 
            Close();
        }
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false; 
            Close();
        }
    }
}
